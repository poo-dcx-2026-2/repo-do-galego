# Entrega 2 — versão com circulação, reservas, relatórios e persistência
