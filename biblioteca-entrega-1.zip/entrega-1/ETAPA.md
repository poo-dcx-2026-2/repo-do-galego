# Entrega 1 — versão de base

Esta versão inclui todas as operações de acervo e usuários solicitadas na Entrega 1. Para preservar compatibilidade com a Entrega 2, já contém implementação adicional de circulação e persistência; não representa histórico real de commits intermediários.

A equipe ainda precisa registrar o teste de regressão de um defeito real em commits distintos e criar PRs com revisão por pares no GitHub.
