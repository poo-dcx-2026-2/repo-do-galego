package br.ufpb.dcx.poo.biblioteca.implementacao;

import br.ufpb.dcx.poo.biblioteca.contrato.*;
import br.ufpb.dcx.poo.biblioteca.contrato.excecoes.*;
import java.time.LocalDate;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
import java.util.stream.*;

/** Fachada por instância: nenhuma coleção é compartilhada entre bibliotecas. */
public final class BibliotecaImpl implements Biblioteca, AcervoService, UsuarioService, EmprestimoService, RelatorioService {
    private static final Comparator<ItemView> TITULO = Comparator.comparing(ItemView::titulo, String.CASE_INSENSITIVE_ORDER).thenComparing(ItemView::codigo);
    private final Map<String, Item> itens = new LinkedHashMap<>();
    private final Map<String, Exemplar> exemplares = new LinkedHashMap<>();
    private final Map<String, Usuario> usuarios = new LinkedHashMap<>();
    private final Map<String, Emprestimo> emprestimos = new LinkedHashMap<>();
    private final Map<String, Reserva> reservas = new LinkedHashMap<>();
    private long sequenciaEmprestimo, sequenciaReserva;
    private static final class Item {
        final String codigo, titulo, autoria, categoria; final int ano;
        Item(String c,String t,String a,String g,int y){codigo=c;titulo=t;autoria=a;categoria=g;ano=y;}
    }
    private static final class Exemplar {
        final String tombo, item; StatusExemplar status=StatusExemplar.DISPONIVEL; String reserva;
        Exemplar(String t,String i){tombo=t;item=i;}
    }
    private static final class Usuario {
        final String matricula,nome; boolean ativo=true;
        Usuario(String m,String n){matricula=m;nome=n;}
    }
    private static final class Emprestimo {
        final String id,tombo,matricula; final LocalDate inicio,prevista; LocalDate devolucao;
        Emprestimo(String id,String t,String m,LocalDate d){this.id=id;tombo=t;matricula=m;inicio=d;prevista=d.plusDays(PRAZO_EM_DIAS);}
        boolean ativo(){return devolucao==null;}
        boolean atrasado(LocalDate data){return ativo() && prevista.isBefore(data);}
        EmprestimoView view(LocalDate referencia){return new EmprestimoView(id,tombo,matricula,inicio,prevista,devolucao,referencia!=null&&atrasado(referencia)?StatusEmprestimo.ATRASADO:ativo()?StatusEmprestimo.ATIVO:StatusEmprestimo.DEVOLVIDO);}
    }
    private static final class Reserva {
        final String id,item,matricula; final LocalDate data; String tombo;
        Reserva(String id,String i,String m,LocalDate d){this.id=id;item=i;matricula=m;data=d;}
    }
    private static String texto(String valor,String campo){if(valor==null||valor.isBlank())throw new DadosInvalidosException(campo+" obrigatório");return valor.trim();}
    private static LocalDate data(LocalDate d){if(d==null)throw new DadosInvalidosException("data obrigatória");return d;}
    private Item item(String codigo)throws RecursoNaoEncontradoException {Item i=itens.get(codigo);if(i==null)throw new RecursoNaoEncontradoException("Item não encontrado: "+codigo);return i;}
    private Exemplar exemplar(String tombo)throws RecursoNaoEncontradoException {Exemplar e=exemplares.get(tombo);if(e==null)throw new RecursoNaoEncontradoException("Exemplar não encontrado: "+tombo);return e;}
    private Usuario usuario(String matricula)throws RecursoNaoEncontradoException {Usuario u=usuarios.get(matricula);if(u==null)throw new RecursoNaoEncontradoException("Usuário não encontrado: "+matricula);return u;}
    private long ativos(String matricula){return emprestimos.values().stream().filter(e->e.ativo()&&e.matricula.equals(matricula)).count();}
    private ItemView view(Item i){int total=0,livres=0;for(Exemplar e:exemplares.values())if(e.item.equals(i.codigo)){total++;if(e.status==StatusExemplar.DISPONIVEL)livres++;}return new ItemView(i.codigo,i.titulo,i.autoria,i.categoria,i.ano,total,livres);}
    private UsuarioView view(Usuario u){return new UsuarioView(u.matricula,u.nome,u.ativo,(int)ativos(u.matricula));}
    @Override public AcervoService acervo(){return this;}
    @Override public UsuarioService usuarios(){return this;}
    @Override public EmprestimoService emprestimos(){return this;}
    @Override public RelatorioService relatorios(){return this;}
    @Override public void cadastrarItem(String c,String t,String a,String g,int y)throws RecursoDuplicadoException{
        c=texto(c,"codigo");t=texto(t,"titulo");a=texto(a,"autoria");g=texto(g,"categoria");if(y<=0)throw new DadosInvalidosException("ano inválido");
        if(itens.containsKey(c))throw new RecursoDuplicadoException("Item duplicado: "+c);itens.put(c,new Item(c,t,a,g,y));
    }
    @Override public ItemView buscarItem(String c)throws RecursoNaoEncontradoException{return view(item(texto(c,"codigo")));}
    @Override public List<ItemView> listarItens(){return itens.values().stream().map(this::view).sorted(TITULO).toList();}
    @Override public List<ItemView> buscarPorTitulo(String trecho){String q=texto(trecho,"trecho").toLowerCase(Locale.ROOT);return listarItens().stream().filter(i->i.titulo().toLowerCase(Locale.ROOT).contains(q)).toList();}
    @Override public List<ItemView> buscarPorCategoria(String categoria){String q=texto(categoria,"categoria");return listarItens().stream().filter(i->i.categoria().equalsIgnoreCase(q)).toList();}
    @Override public void adicionarExemplar(String c,String t)throws RecursoNaoEncontradoException,RecursoDuplicadoException{
        c=texto(c,"codigo");t=texto(t,"tombo");item(c);if(exemplares.containsKey(t))throw new RecursoDuplicadoException("Tombo duplicado: "+t);exemplares.put(t,new Exemplar(t,c));
    }
    @Override public List<ExemplarView> listarExemplares(String c)throws RecursoNaoEncontradoException{
        c=texto(c,"codigo");item(c);final String codigo=c;return exemplares.values().stream().filter(e->e.item.equals(codigo)).map(e->new ExemplarView(e.tombo,e.item,e.status)).sorted(Comparator.comparing(ExemplarView::tombo)).toList();
    }
    @Override public void baixarExemplar(String t)throws RecursoNaoEncontradoException,OperacaoNaoPermitidaException{
        Exemplar e=exemplar(texto(t,"tombo"));if(e.status==StatusExemplar.EMPRESTADO||e.status==StatusExemplar.INDISPONIVEL||e.status==StatusExemplar.RESERVADO)throw new OperacaoNaoPermitidaException("Exemplar não pode ser baixado");e.status=StatusExemplar.INDISPONIVEL;
    }
    @Override public void cadastrarUsuario(String m,String n)throws RecursoDuplicadoException{
        m=texto(m,"matricula");n=texto(n,"nome");if(usuarios.containsKey(m))throw new RecursoDuplicadoException("Matrícula duplicada");usuarios.put(m,new Usuario(m,n));
    }
    @Override public UsuarioView buscarUsuario(String m)throws RecursoNaoEncontradoException{return view(usuario(texto(m,"matricula")));}
    @Override public List<UsuarioView> listarUsuarios(){return usuarios.values().stream().map(this::view).sorted(Comparator.comparing(UsuarioView::matricula)).toList();}
    @Override public void desativarUsuario(String m)throws RecursoNaoEncontradoException,OperacaoNaoPermitidaException{
        Usuario u=usuario(texto(m,"matricula"));if(ativos(m)>0)throw new OperacaoNaoPermitidaException("Usuário tem empréstimos ativos");u.ativo=false;
    }
    @Override public void reativarUsuario(String m)throws RecursoNaoEncontradoException{usuario(texto(m,"matricula")).ativo=true;}
    @Override public String emprestar(String t,String m,LocalDate d)throws RecursoNaoEncontradoException,ExemplarIndisponivelException,UsuarioInativoException,LimiteDeEmprestimosExcedidoException{
        t=texto(t,"tombo");m=texto(m,"matricula");data(d);Exemplar e=exemplar(t);Usuario u=usuario(m);
        if(!u.ativo)throw new UsuarioInativoException("Usuário inativo");
        if(e.status!=StatusExemplar.DISPONIVEL && !(e.status==StatusExemplar.RESERVADO&&e.reserva!=null&&reservas.containsKey(e.reserva)&&reservas.get(e.reserva).matricula.equals(m)))throw new ExemplarIndisponivelException("Exemplar indisponível");
        if(ativos(m)>=LIMITE_DE_EMPRESTIMOS)throw new LimiteDeEmprestimosExcedidoException("Limite atingido");
        if(e.reserva!=null)reservas.remove(e.reserva);e.reserva=null;e.status=StatusExemplar.EMPRESTADO;
        String id="E-"+(++sequenciaEmprestimo);emprestimos.put(id,new Emprestimo(id,t,m,d));return id;
    }
    @Override public void devolver(String t,LocalDate d)throws RecursoNaoEncontradoException,OperacaoNaoPermitidaException{
        t=texto(t,"tombo");data(d);Exemplar e=exemplar(t);Emprestimo emprestimo=emprestimos.values().stream().filter(x->x.tombo.equals(e.tombo)&&x.ativo()).findFirst().orElse(null);
        if(emprestimo==null)throw new OperacaoNaoPermitidaException("Não há empréstimo ativo");
        if(d.isBefore(emprestimo.inicio))throw new DadosInvalidosException("Devolução anterior ao empréstimo");
        emprestimo.devolucao=d;atribuirProximaReserva(e);
    }
    private void atribuirProximaReserva(Exemplar e){
        e.reserva=null;Reserva r=reservas.values().stream().filter(x->x.item.equals(e.item)&&x.tombo==null).findFirst().orElse(null);
        if(r==null)e.status=StatusExemplar.DISPONIVEL;else{r.tombo=e.tombo;e.reserva=r.id;e.status=StatusExemplar.RESERVADO;}
    }
    @Override public List<EmprestimoView> listarEmprestimosDoUsuario(String m)throws RecursoNaoEncontradoException{
        m=texto(m,"matricula");usuario(m);final String matricula=m;return emprestimos.values().stream().filter(e->e.matricula.equals(matricula)).sorted(Comparator.comparing((Emprestimo e)->e.inicio).reversed().thenComparing(e->e.id,Comparator.reverseOrder())).map(e->e.view(null)).toList();
    }
    @Override public List<EmprestimoView> listarAtrasados(LocalDate d){data(d);return emprestimos.values().stream().filter(e->e.atrasado(d)).map(e->e.view(d)).toList();}
    @Override public String reservar(String c,String m,LocalDate d)throws RecursoNaoEncontradoException,OperacaoNaoPermitidaException{
        c=texto(c,"codigo");m=texto(m,"matricula");data(d);item(c);Usuario u=usuario(m);
        if(!u.ativo)throw new UsuarioInativoException("Usuário inativo");
        final String codigo=c,matricula=m;
        if(exemplares.values().stream().anyMatch(e->e.item.equals(codigo)&&e.status==StatusExemplar.DISPONIVEL))throw new OperacaoNaoPermitidaException("Há exemplar disponível");
        if(reservas.values().stream().anyMatch(r->r.item.equals(codigo)&&r.matricula.equals(matricula)))throw new OperacaoNaoPermitidaException("Reserva duplicada");
        String id="R-"+(++sequenciaReserva);reservas.put(id,new Reserva(id,c,m,d));return id;
    }
    @Override public List<ReservaView> listarReservas(String c)throws RecursoNaoEncontradoException{
        c=texto(c,"codigo");item(c);List<ReservaView> result=new ArrayList<>();int pos=0;for(Reserva r:reservas.values())if(r.item.equals(c))result.add(new ReservaView(r.id,r.item,r.matricula,r.data,++pos));return List.copyOf(result);
    }
    @Override public void cancelarReserva(String id)throws RecursoNaoEncontradoException{
        id=texto(id,"id");Reserva r=reservas.remove(id);if(r==null)throw new RecursoNaoEncontradoException("Reserva não encontrada");if(r.tombo!=null)atribuirProximaReserva(exemplares.get(r.tombo));
    }
    @Override public List<ItemView> itensMaisEmprestados(int n){if(n<0)throw new DadosInvalidosException("n negativo");Map<String,Long> counts=emprestimos.values().stream().collect(Collectors.groupingBy(e->exemplares.get(e.tombo).item,Collectors.counting()));return listarItens().stream().sorted(Comparator.<ItemView>comparingLong(i->counts.getOrDefault(i.codigo(),0L)).reversed().thenComparing(TITULO)).limit(n).toList();}
    @Override public Map<String,Long> emprestimosPorCategoria(){Map<String,Long> r=new TreeMap<>();for(Emprestimo e:emprestimos.values()){String c=itens.get(exemplares.get(e.tombo).item).categoria;r.merge(c,1L,Long::sum);}return Collections.unmodifiableMap(r);}
    @Override public List<UsuarioView> usuariosComAtraso(LocalDate d){data(d);Set<String> matriculas=emprestimos.values().stream().filter(e->e.atrasado(d)).map(e->e.matricula).collect(Collectors.toSet());return listarUsuarios().stream().filter(u->matriculas.contains(u.matricula())).toList();}
    @Override public double taxaDeOcupacaoDoAcervo(){long total=exemplares.values().stream().filter(e->e.status!=StatusExemplar.INDISPONIVEL).count();return total==0?0.0:(double)exemplares.values().stream().filter(e->e.status==StatusExemplar.EMPRESTADO).count()/total;}
    @Override public int importarItensEmLote(Path arquivo)throws PersistenciaException{
        try{int n=0;for(String linha:Files.readAllLines(arquivo,StandardCharsets.UTF_8)){if(linha.isBlank()||linha.startsWith("#"))continue;String[] a=linha.split(";",-1);if(a.length!=5)throw new IOException("Linha inválida");try{cadastrarItem(a[0],a[1],a[2],a[3],Integer.parseInt(a[4]));n++;}catch(RecursoDuplicadoException ignored){}}return n;}catch(Exception ex){throw erro("Erro ao importar itens",ex);}
    }
    private static PersistenciaException erro(String mensagem,Exception causa){PersistenciaException e=new PersistenciaException(mensagem+": "+causa.getMessage());e.initCause(causa);return e;}
    private static Path diretorio(){return Path.of(System.getProperty("biblioteca.dados","dados"));}
    private static String cod(String s){return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8));}
    private static String dec(String s){return new String(Base64.getUrlDecoder().decode(s),StandardCharsets.UTF_8);}
    private static String linha(String... campos){return String.join(";",campos);}
    private static List<String[]> ler(Path dir,String nome)throws IOException{
        Path arquivo=dir.resolve(nome);if(!Files.exists(arquivo))return List.of();List<String[]> linhas=new ArrayList<>();try(BufferedReader r=Files.newBufferedReader(arquivo,StandardCharsets.UTF_8)){String s;while((s=r.readLine())!=null)if(!s.isBlank())linhas.add(s.split(";",-1));}return linhas;
    }
    private static void gravar(Path dir,String nome,List<String> linhas)throws IOException{
        try(BufferedWriter w=Files.newBufferedWriter(dir.resolve(nome),StandardCharsets.UTF_8)){for(String l:linhas){w.write(l);w.newLine();}}
    }
    @Override public void salvar()throws PersistenciaException{
        try{Path dir=diretorio();Files.createDirectories(dir);
            List<String> l=new ArrayList<>();for(Item i:itens.values())l.add(linha(cod(i.codigo),cod(i.titulo),cod(i.autoria),cod(i.categoria),""+i.ano));gravar(dir,"itens.txt",l);
            l.clear();for(Exemplar e:exemplares.values())l.add(linha(cod(e.tombo),cod(e.item),e.status.name(),e.reserva==null?"":cod(e.reserva)));gravar(dir,"exemplares.txt",l);
            l.clear();for(Usuario u:usuarios.values())l.add(linha(cod(u.matricula),cod(u.nome),""+u.ativo));gravar(dir,"usuarios.txt",l);
            l.clear();for(Emprestimo e:emprestimos.values())l.add(linha(cod(e.id),cod(e.tombo),cod(e.matricula),e.inicio.toString(),e.devolucao==null?"":e.devolucao.toString()));gravar(dir,"emprestimos.txt",l);
            l.clear();for(Reserva r:reservas.values())l.add(linha(cod(r.id),cod(r.item),cod(r.matricula),r.data.toString(),r.tombo==null?"":cod(r.tombo)));gravar(dir,"reservas.txt",l);
        }catch(Exception e){throw erro("Falha ao salvar",e);}
    }
    @Override public void carregar()throws PersistenciaException{
        BibliotecaImpl novo=new BibliotecaImpl();Path dir=diretorio();
        try{
            for(String[] a:ler(dir,"itens.txt")){if(a.length!=5)throw new IOException("Item malformado");novo.cadastrarItem(dec(a[0]),dec(a[1]),dec(a[2]),dec(a[3]),Integer.parseInt(a[4]));}
            for(String[] a:ler(dir,"exemplares.txt")){if(a.length!=4)throw new IOException("Exemplar malformado");novo.adicionarExemplar(dec(a[1]),dec(a[0]));Exemplar e=novo.exemplares.get(dec(a[0]));e.status=StatusExemplar.valueOf(a[2]);e.reserva=a[3].isEmpty()?null:dec(a[3]);}
            for(String[] a:ler(dir,"usuarios.txt")){if(a.length!=3)throw new IOException("Usuário malformado");novo.cadastrarUsuario(dec(a[0]),dec(a[1]));novo.usuarios.get(dec(a[0])).ativo=Boolean.parseBoolean(a[2]);}
            for(String[] a:ler(dir,"emprestimos.txt")){if(a.length!=5)throw new IOException("Empréstimo malformado");String id=dec(a[0]),tombo=dec(a[1]),matricula=dec(a[2]);novo.exemplar(tombo);novo.usuario(matricula);Emprestimo e=new Emprestimo(id,tombo,matricula,LocalDate.parse(a[3]));if(!a[4].isEmpty())e.devolucao=LocalDate.parse(a[4]);if(novo.emprestimos.putIfAbsent(id,e)!=null)throw new IOException("ID duplicado");novo.sequenciaEmprestimo=Math.max(novo.sequenciaEmprestimo,Long.parseLong(id.substring(2)));}
            for(String[] a:ler(dir,"reservas.txt")){if(a.length!=5)throw new IOException("Reserva malformada");String id=dec(a[0]),item=dec(a[1]),matricula=dec(a[2]);novo.item(item);novo.usuario(matricula);Reserva r=new Reserva(id,item,matricula,LocalDate.parse(a[3]));if(!a[4].isEmpty()){r.tombo=dec(a[4]);novo.exemplar(r.tombo);}if(novo.reservas.putIfAbsent(id,r)!=null)throw new IOException("ID duplicado");novo.sequenciaReserva=Math.max(novo.sequenciaReserva,Long.parseLong(id.substring(2)));}
            for(Exemplar e:novo.exemplares.values())if(e.reserva!=null&&!novo.reservas.containsKey(e.reserva))throw new IOException("Reserva associada inexistente");
        }catch(Exception e){throw erro("Falha ao carregar",e);}
        itens.clear();itens.putAll(novo.itens);exemplares.clear();exemplares.putAll(novo.exemplares);usuarios.clear();usuarios.putAll(novo.usuarios);emprestimos.clear();emprestimos.putAll(novo.emprestimos);reservas.clear();reservas.putAll(novo.reservas);sequenciaEmprestimo=novo.sequenciaEmprestimo;sequenciaReserva=novo.sequenciaReserva;
    }
    /** Extensão autoral: quantos exemplares disponíveis existem em cada categoria. */
    public Map<String,Long> disponibilidadePorCategoria(){Map<String,Long> r=new TreeMap<>();for(Exemplar e:exemplares.values())if(e.status==StatusExemplar.DISPONIVEL)r.merge(itens.get(e.item).categoria,1L,Long::sum);return Collections.unmodifiableMap(r);}
}
