# Declaração de uso de IA

Foi utilizada assistência de IA (ChatGPT/OpenAI) para apoiar a implementação de classes Java, organização da documentação e elaboração de testes exploratórios. A equipe deve revisar o código, validar os requisitos e preencher aqui as contribuições efetivas de seus integrantes antes da submissão. Não atribuir à equipe revisões ou commits que não tenham ocorrido.
