# Biblioteca / Acervo — Java 21

Projeto de POO construído sobre o template oficial. **O pacote `contrato/` não foi alterado.**

## Executar

Requer JDK 21 e Maven. Na raiz: `mvn -B verify`.

O ponto de entrada é `Fabrica.novaBiblioteca()`; cada chamada cria uma instância vazia e independente.

## Funcionalidades

Cadastro, busca e listagem de itens, exemplares e usuários; busca por título e categoria; baixa de exemplar; ativação/desativação de usuários; empréstimos com prazo de 14 dias e limite de 3; devolução; atraso; reservas FIFO; cancelamento; relatórios; importação; persistência por `salvar()` e `carregar()`.

## Persistência

Diretório padrão `dados/`; configurar com `-Dbiblioteca.dados=/caminho`. Os arquivos `itens.txt`, `exemplares.txt`, `usuarios.txt`, `emprestimos.txt` e `reservas.txt` usam UTF-8, `;` e campos textuais Base64 URL-safe. `carregar()` é explícito e transacional em memória.

## Extensão autoral

`BibliotecaImpl.disponibilidadePorCategoria()` retorna mapa imutável da quantidade de exemplares disponíveis por categoria, sem alterar as interfaces oficiais.

## Organização e decisões

Ver `docs/modelo.puml` e `docs/decisoes.md`. Identidades são finais, coleções são privadas, visões retornadas são records imutáveis. O tombo é globalmente único.

## Entrega colaborativa

A equipe deve criar seu repositório público `equipe-NN-acervo`, configurar o e-mail privado GitHub, abrir PRs e registrar revisão real de outro integrante. Essas ações não foram simuladas no pacote.

## Limitações de verificação

A compilação com `javac` (JDK 21) e um teste de integração simples foram executados. A execução integral do Maven/JUnit e os testes ocultos do professor ainda precisam ser verificados no ambiente da equipe.
