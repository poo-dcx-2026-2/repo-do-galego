package br.ufpb.dcx.poo.biblioteca;
import br.ufpb.dcx.poo.biblioteca.contrato.Biblioteca;
import br.ufpb.dcx.poo.biblioteca.implementacao.BibliotecaImpl;
public final class Fabrica {
    private Fabrica() {}
    public static Biblioteca novaBiblioteca() { return new BibliotecaImpl(); }
}
