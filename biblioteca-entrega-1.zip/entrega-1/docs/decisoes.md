# Decisões arquiteturais

- **Composição em vez de herança:** a biblioteca mantém mapas privados de entidades e fornece serviços por uma fachada (`BibliotecaImpl`). As entidades não herdam de coleções.
- **GRASP — Information Expert:** `Emprestimo` conhece as datas de empréstimo, vencimento e devolução e calcula o atraso.
- **GRASP — Creator:** a fachada cria itens, exemplares, usuários, empréstimos e reservas e mantém as associações consistentes.
- **Facade:** `Fabrica.novaBiblioteca()` devolve uma nova `BibliotecaImpl`, que expõe as quatro interfaces contratuais.
- **Reservas de usuário desativado:** reservas existentes permanecem na fila, mas o empréstimo é bloqueado enquanto o usuário estiver inativo.
- **Coleções:** `Map` para unicidade e localização por código/tombo/matrícula; `LinkedHashMap` para manter a ordem de chegada da fila; `List` imutável nos resultados; `Set` na apuração de usuários em atraso.
- **Persistência:** arquivos UTF-8 com campos codificados em Base64 URL-safe para não conflitar com `;`. A carga usa estado temporário e somente substitui os mapas depois de validar os arquivos.
